#include "PLACEHOLDERPhysics.h"


PLACEHOLDERPhysics::PLACEHOLDERPhysics ()
{
}


PLACEHOLDERPhysics::~PLACEHOLDERPhysics ()
{
}
