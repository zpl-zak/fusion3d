#pragma once

#include "E:\Fusion3D_work\engine\src\physics\physicsEngine.h"

class PLACEHOLDERPhysics : public PhysicsEngine
{
public:
	PLACEHOLDERPhysics ();
	~PLACEHOLDERPhysics ();
};

