// DO NOT EDIT. USE BUILD TOOL FOR UPDATES.

#pragma once

#include "3DEngine.h"

inline void RegisterUserspace (CoreEngine* engine)
{

}