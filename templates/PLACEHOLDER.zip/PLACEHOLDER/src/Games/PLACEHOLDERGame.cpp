#include "PLACEHOLDERGame.h"

void PLACEHOLDERGame::Init (const Window& window)
{

}
