#pragma once

#include "physics\physicsEngine.h"

class PLACEHOLDERPhysics : public PhysicsEngine
{
public:
	PLACEHOLDERPhysics ();
	~PLACEHOLDERPhysics ();
};

