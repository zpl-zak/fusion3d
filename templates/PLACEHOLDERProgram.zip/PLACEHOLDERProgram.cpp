#include "PLACEHOLDERProgram.h"


PLACEHOLDERProgram::PLACEHOLDERProgram ()
{
}


PLACEHOLDERProgram::~PLACEHOLDERProgram ()
{
}

int PLACEHOLDERProgram::Init ()
{
	return 1;
}

int PLACEHOLDERProgram::ProcessInput (const Input & input, float delta)
{
	return 1;
}

int PLACEHOLDERProgram::Update (float delta)
{
	return 1;
}

int PLACEHOLDERProgram::Render (Shader & shader, const RenderingEngine & renderingEngine, const Camera & camera)
{
	return 1;
}
