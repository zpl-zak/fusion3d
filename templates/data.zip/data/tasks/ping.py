import sys
print "Pong to " + sys.argv[1]