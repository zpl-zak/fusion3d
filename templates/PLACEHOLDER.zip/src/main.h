#pragma once


#ifdef _DEBUG
#pragma comment(lib, "Fusion3D_Debug.lib")
#else
#pragma comment(lib, "Fusion3D.lib")
#endif

#include "main.generated.h"
#include <Windows.h>

int CALLBACK WinMain (
	_In_ HINSTANCE hInstance,
	_In_ HINSTANCE hPrevInstance,
	_In_ LPSTR     lpCmdLine,
	_In_ int       nCmdShow
	);