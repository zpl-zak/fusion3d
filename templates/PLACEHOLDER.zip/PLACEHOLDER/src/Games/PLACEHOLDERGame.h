#pragma once

#include "3DEngine.h"

class PLACEHOLDERGame : public Game
{
public:
	PLACEHOLDERGame ()
	{

	}

	virtual ~PLACEHOLDERGame ()
	{

	}

	virtual void Init (const Window& window);
protected:
	//-----
private:
	PLACEHOLDERGame (const PLACEHOLDERGame& other) {}
	void operator=(const PLACEHOLDERGame& other) {}
};
